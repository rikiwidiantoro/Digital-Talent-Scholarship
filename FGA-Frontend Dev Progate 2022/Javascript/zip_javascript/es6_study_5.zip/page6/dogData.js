import Dog from "../class/dog";

const dog1 = new Dog("Leo", 4, "Chihuahua");
const dog2 = new Dog("Ben", 2, "Poodle");

export { dog1, dog2 };