// Pindahkan pendefinisian class Animal ke animal.js dan hapus code dibawah


// Pindahkan pendefinisian class Dog ke dog.js dan hapus code dibawah


// Code dibawah jangan diganggu karena bukan bagian dari class Animal ataupun Dog
const dog = new Dog("Leo", 4, "Chihuahua");
dog.info();
