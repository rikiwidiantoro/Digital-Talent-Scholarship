const character = {name: "Ninja Ken", age: 14};

// Print nilai property name milik character
console.log(character.name);

// Gantikan nilai age milik character ke 20 
character.age = 20;

// Print constant character ke console
console.log(character);
