// Deklarasikan variable number
let number = 1;

// Tambahkan while loop dibawah
while(number <=100 ) {
  console.log(number);
  number++;
}
