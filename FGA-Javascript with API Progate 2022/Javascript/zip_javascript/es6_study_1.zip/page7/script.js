// Deklarasikan variable length
let length = 5;

// Cetak nilai variable length
console.log(length);

// Gunakan variable length untuk mencetak hasil area lingkaran
console.log(length * length * 3);
