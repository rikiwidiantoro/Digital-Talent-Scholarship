const name = "Ninja Ken";
const age = 14;

// Cetak string "Nama saya adalah ____"
console.log(`Nama saya adalah ${name}`);

// Cetak string "Hari ini saya berusia ____ tahun"
console.log(`Hari ini saya berusia ${age} tahun`);
