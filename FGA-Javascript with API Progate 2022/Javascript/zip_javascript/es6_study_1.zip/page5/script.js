// Cetak kombinasi dari string "Guru " dan "Domba"
console.log("Guru" + " Domba");

// Cetak kombinasi dari "20" dan "15" (dan jadikan sebagai string)
console.log("20" + "15");
