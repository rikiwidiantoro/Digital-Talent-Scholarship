const password = "ninjaken";

// Ketika nilai password adalah "ninjaken", cetak "Berhasil log in"
if( password === "ninjaken" ) {
  console.log("Berhasil log in");
} else if( password !== "ninjaken" ) {
  console.log("Password salah");
}

// Ketika nilai password bukan "ninjaken", cetak "Password salah"
